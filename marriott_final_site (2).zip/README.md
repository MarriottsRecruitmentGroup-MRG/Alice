
# Marriott International Recruitment (MRG)

Welcome to the official Marriott International Group Recruitment Portal.

🌐 We are offering **worldwide remote job opportunities** — flexible, supportive, and designed to help you grow.

🚀 Apply today and join our international team.

---

## Quick Links
- 🌍 [Visit Website](https://marriottsrecruitmentgroup-mrg.github.io/Alice/)
- 📩 Telegram: [@Marriotts_RecruitmentTeam](https://t.me/Marriotts_RecruitmentTeam)

---

© 2025 Marriott International Group
